<html>

    <head>
      
	 <meta charset = "utf-8">
     <title>Projeto User </title>
		
	</head>
		<style>
		
 		    #botao {
			 
			 position: relative;
			 width: 300px;
			 height: 50px;
			 background: lightblue;
			 font-size: 30px;
			 font-color: darkblack;
			 padding: 2px
			 bolder: 1px;
			 border-radius: 7px;
		    }
			
			#grad {
                background-image: linear-gradient(to right, darkcyan,cyan,lightcyan,white,lightgray,gray,darkgray);
				font-size: 50px;
            }
		
		</style>

        <body id = "grad">

    

        <h1>!!Logout efetuado com sucesso!!</h1>
		
		
		<center><button type="submit" name="botao" id = "botao"><a href = "login.php">Página Inicial</a></button></center>
		
		
		

        </body>
</html>